Character.create([
	{team: 1, unit: 'mage'}, 
	{team: 1, unit: 'knight'}, 
	{team: 2, unit: 'jinn'}, 
	{team: 2, unit: 'medusa'}
])