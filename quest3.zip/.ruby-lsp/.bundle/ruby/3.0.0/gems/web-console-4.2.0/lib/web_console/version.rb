# frozen_string_literal: true

module WebConsole
  VERSION = "4.2.0"
end
