# frozen_string_literal: true

require "web_console"
